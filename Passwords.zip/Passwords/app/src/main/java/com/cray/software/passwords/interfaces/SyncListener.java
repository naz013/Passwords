package com.cray.software.passwords.interfaces;

public interface SyncListener {
    void endExecution(boolean result);
}
